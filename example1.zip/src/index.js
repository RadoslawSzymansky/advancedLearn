import { message, messageDOM } from './message';

message("działam po bundlingu!");
messageDOM("działa po bundlingu w przeglądarce");
