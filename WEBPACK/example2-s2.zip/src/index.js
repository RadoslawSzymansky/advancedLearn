import { message, messageDOM } from './tools/message';
import './components/footer'
import info from './data/title.txt';
import './css/style.css';

message(info);
messageDOM(info);
