export const message = (info) => console.log(info);
export const messageDOM = (info) => document.body.textContent = info;
const a = 555;
