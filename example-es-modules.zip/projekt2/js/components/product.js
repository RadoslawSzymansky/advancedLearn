const info = {
  name: 'rower',
  age: 'new',
  price: 99.99,
  HTMLElement: 'h2',
};

export default info;
