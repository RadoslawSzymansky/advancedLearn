export const a = "zmienna 1";
