const b = 'zmienna druga';
export default b;
